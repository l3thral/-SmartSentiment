from transformers import pipeline

# Load sentiment-analysis pipeline
model = pipeline("sentiment-analysis")

def analyze_text(text):
    result = model(text)[0]
    return {"label": result["label"], "score": result["score"]}
