using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Windows;

namespace WpfClient
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void AnalyzeButton_Click(object sender, RoutedEventArgs e)
        {
            var inputText = InputTextBox.Text;
            using var client = new HttpClient();
            var content = new StringContent(
                JsonSerializer.Serialize(new { text = inputText }),
                Encoding.UTF8,
                "application/json");

            var response = await client.PostAsync("http://localhost:5000/analyze", content);
            var resultJson = await response.Content.ReadAsStringAsync();

            var result = JsonSerializer.Deserialize<SentimentResult>(resultJson);
            ResultTextBlock.Text = $"Label: {result.label}, Score: {result.score:F2}";
        }
    }

    public class SentimentResult
    {
        public string label { get; set; }
        public float score { get; set; }
    }
}
